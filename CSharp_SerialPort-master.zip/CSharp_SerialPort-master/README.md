# CSharp_SerialPort
This is a simple C# SerialPort  project. 
https://youtu.be/tYBAT6OVgVc
